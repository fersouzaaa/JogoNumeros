/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package somativa2;

import java.awt.Color;

/**
 *
 * @author aluno
 */
public class SOMATIVA2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      /*String sDigito1= sNum.substring(0,1);
        String Tent1=tfTentativa1.getText();
        String sDigito2= sNum.substring(1,2);
        String Tent2=tfTentativa2.getText();
        String sDigito3= sNum.substring(2,3);
        String Tent3=tfTentativa3.getText();
        String sDigito4= sNum.substring(3,4);
        String Tent4=tfTentativa4.getText();
        String sDigito5= sNum.substring(4,5);
        String Tent5=tfTentativa5.getText();
        if (iConta==4 || iConta==9 || iConta==14 || iConta==19 || iConta==24 || iConta==29){
            if(iConta==4){
                if (Tent1.equalsIgnoreCase(sDigito1)){
                    tfTentativa1.setBackground(Color.green);
                }else {
                    tfTentativa1.setBackground(Color.lightGray);
                }
                if (Tent2.equalsIgnoreCase(sDigito2)){
                    tfTentativa2.setBackground(Color.green);
                }else {
                    tfTentativa2.setBackground(Color.lightGray);
                }
                if (Tent3.equalsIgnoreCase(sDigito3)){
                    tfTentativa3.setBackground(Color.green);
                }else {
                    tfTentativa3.setBackground(Color.lightGray);
                }
                if (Tent4.equalsIgnoreCase(sDigito4)){
                    tfTentativa4.setBackground(Color.green);
                }else {
                    tfTentativa4.setBackground(Color.lightGray);
                }
                if (Tent5.equalsIgnoreCase(sDigito5)){
                    tfTentativa5.setBackground(Color.green);
                }else {
                    tfTentativa5.setBackground(Color.lightGray);
                }
            }
        }else{
            System.out.println("digita o resto dos numeros");
        }
    }*/
         }
}
