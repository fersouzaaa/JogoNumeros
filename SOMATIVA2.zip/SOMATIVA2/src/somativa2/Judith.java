/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package somativa2;

import java.awt.Color;
import java.awt.TextField;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 *
 * @author aluno
 */
public class Judith extends javax.swing.JFrame {

    /**
     * Creates new form Judith
     */
    JTextField[] tf;
    public Judith() {
        initComponents();
        lbPlacar.setText(String.valueOf(iPlacar));
        tfTentativa1.requestFocus();
        tf = new JTextField[30];
        tf[0]=tfTentativa1;
        tf[1]=tfTentativa2;
        tf[2]=tfTentativa3;
        tf[3]=tfTentativa4;
        tf[4]=tfTentativa5;
        tf[5]=tfTentativa6;
        tf[6]=tfTentativa7;
        tf[7]=tfTentativa8;
        tf[8]=tfTentativa9;
        tf[9]=tfTentativa10;
        tf[10]=tfTentativa11;
        tf[11]=tfTentativa12;
        tf[12]=tfTentativa13;
        tf[13]=tfTentativa14;
        tf[14]=tfTentativa15;
        tf[15]=tfTentativa16;
        tf[16]=tfTentativa17;
        tf[17]=tfTentativa18;
        tf[18]=tfTentativa19;
        tf[19]=tfTentativa20;
        tf[20]=tfTentativa21;
        tf[21]=tfTentativa22;
        tf[22]=tfTentativa23;
        tf[23]=tfTentativa24;
        tf[24]=tfTentativa25;
        tf[25]=tfTentativa26;
        tf[26]=tfTentativa27;
        tf[27]=tfTentativa28;
        tf[28]=tfTentativa29;
        tf[29]=tfTentativa30;
        Sortear();
        tf[0].requestFocus();
    }
    public String[] PegarDigitos(){
        String[] sDigito= {sNum.substring(0,1),
                sNum.substring(1,2),
                sNum.substring(2,3),
                sNum.substring(3,4),
                sNum.substring(4,5)};
        return sDigito;
    }
    public void TestarLinha1 (){
        String[] sDigito= PegarDigitos();
        if (tfTentativa1.getText().equalsIgnoreCase(sDigito[0])){
            tfTentativa1.setBackground(Color.green);
        }else if (tfTentativa1.getText().equalsIgnoreCase(sDigito[1]) ||
                tfTentativa1.getText().equalsIgnoreCase(sDigito[2])||
                tfTentativa1.getText().equalsIgnoreCase(sDigito[3]) ||
                tfTentativa1.getText().equalsIgnoreCase(sDigito[4])){
            tfTentativa1.setBackground(Color.yellow);
        }else{
            tfTentativa1.setBackground(Color.lightGray);
        }
        if (tfTentativa2.getText().equalsIgnoreCase(sDigito[1])){
            tfTentativa2.setBackground(Color.green);
        }else if (tfTentativa2.getText().equalsIgnoreCase(sDigito[0]) ||
                tfTentativa2.getText().equalsIgnoreCase(sDigito[2])||
                tfTentativa2.getText().equalsIgnoreCase(sDigito[3]) ||
                tfTentativa2.getText().equalsIgnoreCase(sDigito[4]) &&
                tfTentativa1.getBackground()!=Color.green){
            tfTentativa2.setBackground(Color.yellow);
        }else{
            tfTentativa2.setBackground(Color.lightGray);
        }
        if (tfTentativa3.getText().equalsIgnoreCase(sDigito[2])){
            tfTentativa3.setBackground(Color.green);
        }else if (tfTentativa3.getText().equalsIgnoreCase(sDigito[0]) ||
                tfTentativa3.getText().equalsIgnoreCase(sDigito[1])||
                tfTentativa3.getText().equalsIgnoreCase(sDigito[3]) ||
                tfTentativa3.getText().equalsIgnoreCase(sDigito[4]) &&
                tfTentativa2.getBackground()!=Color.green){
            tfTentativa3.setBackground(Color.yellow);
        }else{
            tfTentativa3.setBackground(Color.lightGray);
        }
        if (tfTentativa4.getText().equalsIgnoreCase(sDigito[3])){
            tfTentativa4.setBackground(Color.green);
        }else if (tfTentativa4.getText().equalsIgnoreCase(sDigito[0]) ||
                tfTentativa4.getText().equalsIgnoreCase(sDigito[2])||
                tfTentativa4.getText().equalsIgnoreCase(sDigito[1]) ||
                tfTentativa4.getText().equalsIgnoreCase(sDigito[4])
                ){
            tfTentativa4.setBackground(Color.yellow);
        }else{
            tfTentativa4.setBackground(Color.lightGray);
        }
        if (tfTentativa5.getText().equalsIgnoreCase(sDigito[4])){
            tfTentativa5.setBackground(Color.green);
        }else if (tfTentativa5.getText().equalsIgnoreCase(sDigito[0]) ||
                tfTentativa5.getText().equalsIgnoreCase(sDigito[2])||
                tfTentativa5.getText().equalsIgnoreCase(sDigito[1]) ||
                tfTentativa5.getText().equalsIgnoreCase(sDigito[3]) &&
                tfTentativa4.getBackground()!=Color.green){
            tfTentativa5.setBackground(Color.yellow);
        }else{
            tfTentativa5.setBackground(Color.lightGray);
        }
        tfTentativa5.requestFocus();
        iConta++;
    }
    public void TestarLinha2 (){
                String[] sDigito= PegarDigitos();
        if (tfTentativa6.getText().equalsIgnoreCase(sDigito[0])){
            tfTentativa6.setBackground(Color.green);
        }else if (tfTentativa6.getText().equalsIgnoreCase(sDigito[1]) ||
                tfTentativa6.getText().equalsIgnoreCase(sDigito[2])||
                tfTentativa6.getText().equalsIgnoreCase(sDigito[3]) ||
                tfTentativa6.getText().equalsIgnoreCase(sDigito[4])){
            tfTentativa6.setBackground(Color.yellow);
        }else{
            tfTentativa6.setBackground(Color.lightGray);
        }
        if (tfTentativa7.getText().equalsIgnoreCase(sDigito[1])){
            tfTentativa7.setBackground(Color.green);
        }else if (tfTentativa7.getText().equalsIgnoreCase(sDigito[0]) ||
                tfTentativa7.getText().equalsIgnoreCase(sDigito[2])||
                tfTentativa7.getText().equalsIgnoreCase(sDigito[3]) ||
                tfTentativa7.getText().equalsIgnoreCase(sDigito[4]) &&
                tfTentativa6.getBackground()!=Color.green){
            tfTentativa7.setBackground(Color.yellow);
        }else{
            tfTentativa7.setBackground(Color.lightGray);
        }
        if (tfTentativa8.getText().equalsIgnoreCase(sDigito[2])){
            tfTentativa8.setBackground(Color.green);
        }else if (tfTentativa8.getText().equalsIgnoreCase(sDigito[0]) ||
                tfTentativa8.getText().equalsIgnoreCase(sDigito[1])||
                tfTentativa8.getText().equalsIgnoreCase(sDigito[3]) ||
                tfTentativa8.getText().equalsIgnoreCase(sDigito[4]) &&
                tfTentativa7.getBackground()!=Color.green){
            tfTentativa8.setBackground(Color.yellow);
        }else{
            tfTentativa8.setBackground(Color.lightGray);
        }
        if (tfTentativa9.getText().equalsIgnoreCase(sDigito[3])){
            tfTentativa9.setBackground(Color.green);
        }else if (tfTentativa9.getText().equalsIgnoreCase(sDigito[0]) ||
                tfTentativa9.getText().equalsIgnoreCase(sDigito[2])||
                tfTentativa9.getText().equalsIgnoreCase(sDigito[1]) ||
                tfTentativa9.getText().equalsIgnoreCase(sDigito[4])){
            tfTentativa9.setBackground(Color.yellow);
        }else{
            tfTentativa9.setBackground(Color.lightGray);
        }
        if (tfTentativa10.getText().equalsIgnoreCase(sDigito[4])){
            tfTentativa10.setBackground(Color.green);
        }else if (tfTentativa10.getText().equalsIgnoreCase(sDigito[0]) ||
                tfTentativa10.getText().equalsIgnoreCase(sDigito[2])||
                tfTentativa10.getText().equalsIgnoreCase(sDigito[1]) ||
                tfTentativa10.getText().equalsIgnoreCase(sDigito[3]) &&
                tfTentativa9.getBackground()!=Color.green){
            tfTentativa10.setBackground(Color.yellow);
        }else{
            tfTentativa10.setBackground(Color.lightGray);
        }
        tfTentativa11.requestFocus();
        iConta++;
    }
    public void TestarLinha3 (){
                String[] sDigito= PegarDigitos();
        if (tfTentativa11.getText().equalsIgnoreCase(sDigito[0])){
            tfTentativa11.setBackground(Color.green);
        }else if (tfTentativa11.getText().equalsIgnoreCase(sDigito[1]) ||
                tfTentativa11.getText().equalsIgnoreCase(sDigito[2])||
                tfTentativa11.getText().equalsIgnoreCase(sDigito[3]) ||
                tfTentativa11.getText().equalsIgnoreCase(sDigito[4])){
            tfTentativa11.setBackground(Color.yellow);
        }else{
            tfTentativa11.setBackground(Color.lightGray);
        }
        if (tfTentativa12.getText().equalsIgnoreCase(sDigito[1])){
            tfTentativa12.setBackground(Color.green);
        }else if (tfTentativa12.getText().equalsIgnoreCase(sDigito[0]) ||
                tfTentativa12.getText().equalsIgnoreCase(sDigito[2])||
                tfTentativa12.getText().equalsIgnoreCase(sDigito[3]) ||
                tfTentativa12.getText().equalsIgnoreCase(sDigito[4]) &&
                tfTentativa11.getBackground()!=Color.green){
            tfTentativa12.setBackground(Color.yellow);
        }else{
            tfTentativa12.setBackground(Color.lightGray);
        }
        if (tfTentativa13.getText().equalsIgnoreCase(sDigito[2])){
            tfTentativa13.setBackground(Color.green);
        }else if (tfTentativa13.getText().equalsIgnoreCase(sDigito[0]) ||
                tfTentativa13.getText().equalsIgnoreCase(sDigito[1])||
                tfTentativa13.getText().equalsIgnoreCase(sDigito[3]) ||
                tfTentativa13.getText().equalsIgnoreCase(sDigito[4]) &&
                tfTentativa12.getBackground()!=Color.green){
            tfTentativa13.setBackground(Color.yellow);
        }else{
            tfTentativa13.setBackground(Color.lightGray);
        }
        if (tfTentativa14.getText().equalsIgnoreCase(sDigito[3])){
            tfTentativa14.setBackground(Color.green);
        }else if (tfTentativa14.getText().equalsIgnoreCase(sDigito[0]) ||
                tfTentativa14.getText().equalsIgnoreCase(sDigito[2])||
                tfTentativa14.getText().equalsIgnoreCase(sDigito[1]) ||
                tfTentativa14.getText().equalsIgnoreCase(sDigito[4])){
            tfTentativa14.setBackground(Color.yellow);
        }else{
            tfTentativa14.setBackground(Color.lightGray);
        }
        if (tfTentativa15.getText().equalsIgnoreCase(sDigito[4])){
            tfTentativa15.setBackground(Color.green);
        }else if (tfTentativa15.getText().equalsIgnoreCase(sDigito[0]) ||
                tfTentativa15.getText().equalsIgnoreCase(sDigito[2])||
                tfTentativa15.getText().equalsIgnoreCase(sDigito[1]) ||
                tfTentativa15.getText().equalsIgnoreCase(sDigito[3]) &&
                tfTentativa14.getBackground()!=Color.green){
            tfTentativa15.setBackground(Color.yellow);
        }else{
            tfTentativa15.setBackground(Color.lightGray);
        }
        tfTentativa16.requestFocus();
        iConta++;
    }
    public void TestarLinha4 (){
        String[] sDigito= PegarDigitos();
        if (tfTentativa16.getText().equalsIgnoreCase(sDigito[0])){
            tfTentativa16.setBackground(Color.green);
        }else if (tfTentativa16.getText().equalsIgnoreCase(sDigito[1]) ||
                tfTentativa16.getText().equalsIgnoreCase(sDigito[2])||
                tfTentativa16.getText().equalsIgnoreCase(sDigito[3]) ||
                tfTentativa16.getText().equalsIgnoreCase(sDigito[4])){
            tfTentativa16.setBackground(Color.yellow);
        }else{
            tfTentativa16.setBackground(Color.lightGray);
        }
        if (tfTentativa17.getText().equalsIgnoreCase(sDigito[1])){
            tfTentativa17.setBackground(Color.green);
        }else if (tfTentativa17.getText().equalsIgnoreCase(sDigito[0]) ||
                tfTentativa17.getText().equalsIgnoreCase(sDigito[2])||
                tfTentativa17.getText().equalsIgnoreCase(sDigito[3]) ||
                tfTentativa17.getText().equalsIgnoreCase(sDigito[4]) &&
                tfTentativa16.getBackground()!=Color.green){
            tfTentativa17.setBackground(Color.yellow);
        }else{
            tfTentativa17.setBackground(Color.lightGray);
        }
        if (tfTentativa18.getText().equalsIgnoreCase(sDigito[2])){
            tfTentativa18.setBackground(Color.green);
        }else if (tfTentativa18.getText().equalsIgnoreCase(sDigito[0]) ||
                tfTentativa18.getText().equalsIgnoreCase(sDigito[1])||
                tfTentativa18.getText().equalsIgnoreCase(sDigito[3]) ||
                tfTentativa18.getText().equalsIgnoreCase(sDigito[4]) &&
                tfTentativa17.getBackground()!=Color.green){
            tfTentativa18.setBackground(Color.yellow);
        }else{
            tfTentativa18.setBackground(Color.lightGray);
        }
        if (tfTentativa19.getText().equalsIgnoreCase(sDigito[3])){
            tfTentativa19.setBackground(Color.green);
        }else if (tfTentativa19.getText().equalsIgnoreCase(sDigito[0]) ||
                tfTentativa19.getText().equalsIgnoreCase(sDigito[2])||
                tfTentativa19.getText().equalsIgnoreCase(sDigito[1]) ||
                tfTentativa19.getText().equalsIgnoreCase(sDigito[4])){
            tfTentativa19.setBackground(Color.yellow);
        }else{
            tfTentativa19.setBackground(Color.lightGray);
        }
        if (tfTentativa20.getText().equalsIgnoreCase(sDigito[4])){
            tfTentativa20.setBackground(Color.green);
        }else if (tfTentativa20.getText().equalsIgnoreCase(sDigito[0]) ||
                tfTentativa20.getText().equalsIgnoreCase(sDigito[2])||
                tfTentativa20.getText().equalsIgnoreCase(sDigito[1]) ||
                tfTentativa20.getText().equalsIgnoreCase(sDigito[3]) &&
                tfTentativa19.getBackground()!=Color.green){
            tfTentativa20.setBackground(Color.yellow);
        }else{
            tfTentativa20.setBackground(Color.lightGray);
        }
        tfTentativa21.requestFocus();
        iConta++;
    }
    public void TestarLinha5 (){
        String[] sDigito= PegarDigitos();
        if (tfTentativa21.getText().equalsIgnoreCase(sDigito[0])){
            tfTentativa21.setBackground(Color.green);
        }else if (tfTentativa21.getText().equalsIgnoreCase(sDigito[1]) ||
                tfTentativa21.getText().equalsIgnoreCase(sDigito[2])||
                tfTentativa21.getText().equalsIgnoreCase(sDigito[3]) ||
                tfTentativa21.getText().equalsIgnoreCase(sDigito[4])){
            tfTentativa21.setBackground(Color.yellow);
        }else{
            tfTentativa21.setBackground(Color.lightGray);
        }
        if (tfTentativa22.getText().equalsIgnoreCase(sDigito[1])){
            tfTentativa22.setBackground(Color.green);
        }else if (tfTentativa22.getText().equalsIgnoreCase(sDigito[0]) ||
                tfTentativa22.getText().equalsIgnoreCase(sDigito[2])||
                tfTentativa22.getText().equalsIgnoreCase(sDigito[3]) ||
                tfTentativa22.getText().equalsIgnoreCase(sDigito[4]) &&
                tfTentativa21.getBackground()!=Color.green){
            tfTentativa22.setBackground(Color.yellow);
        }else{
            tfTentativa22.setBackground(Color.lightGray);
        }
        if (tfTentativa23.getText().equalsIgnoreCase(sDigito[2])){
            tfTentativa23.setBackground(Color.green);
        }else if (tfTentativa23.getText().equalsIgnoreCase(sDigito[0]) ||
                tfTentativa23.getText().equalsIgnoreCase(sDigito[1])||
                tfTentativa23.getText().equalsIgnoreCase(sDigito[3]) ||
                tfTentativa23.getText().equalsIgnoreCase(sDigito[4]) &&
                tfTentativa22.getBackground()!=Color.green){
            tfTentativa23.setBackground(Color.yellow);
        }else{
            tfTentativa23.setBackground(Color.lightGray);
        }
        if (tfTentativa24.getText().equalsIgnoreCase(sDigito[3])){
            tfTentativa24.setBackground(Color.green);
        }else if (tfTentativa24.getText().equalsIgnoreCase(sDigito[0]) ||
                tfTentativa24.getText().equalsIgnoreCase(sDigito[2])||
                tfTentativa24.getText().equalsIgnoreCase(sDigito[1]) ||
                tfTentativa24.getText().equalsIgnoreCase(sDigito[4])){
            tfTentativa24.setBackground(Color.yellow);
        }else{
            tfTentativa24.setBackground(Color.lightGray);
        }
        if (tfTentativa25.getText().equalsIgnoreCase(sDigito[4])){
            tfTentativa25.setBackground(Color.green);
        }else if (tfTentativa25.getText().equalsIgnoreCase(sDigito[0]) ||
                tfTentativa25.getText().equalsIgnoreCase(sDigito[2])||
                tfTentativa25.getText().equalsIgnoreCase(sDigito[1]) ||
                tfTentativa25.getText().equalsIgnoreCase(sDigito[3]) &&
                tfTentativa24.getBackground()!=Color.green){
            tfTentativa25.setBackground(Color.yellow);
        }else{
            tfTentativa25.setBackground(Color.lightGray);
        }
        tfTentativa26.requestFocus();
        iConta++;
        
    }
    public void TestarLinha6 (){
        String[] sDigito= PegarDigitos();
        if (tfTentativa26.getText().equalsIgnoreCase(sDigito[0])){
            tfTentativa26.setBackground(Color.green);
        }else if (tfTentativa26.getText().equalsIgnoreCase(sDigito[1]) ||
                tfTentativa26.getText().equalsIgnoreCase(sDigito[2])||
                tfTentativa26.getText().equalsIgnoreCase(sDigito[3]) ||
                tfTentativa26.getText().equalsIgnoreCase(sDigito[4])){
            tfTentativa26.setBackground(Color.yellow);
        }else{
            tfTentativa26.setBackground(Color.lightGray);
        }
        if (tfTentativa27.getText().equalsIgnoreCase(sDigito[1])){
            tfTentativa27.setBackground(Color.green);
        }else if (tfTentativa27.getText().equalsIgnoreCase(sDigito[0]) ||
                tfTentativa27.getText().equalsIgnoreCase(sDigito[2])||
                tfTentativa27.getText().equalsIgnoreCase(sDigito[3]) ||
                tfTentativa27.getText().equalsIgnoreCase(sDigito[4]) &&
                tfTentativa26.getBackground()!=Color.green){
            tfTentativa27.setBackground(Color.yellow);
        }else{
            tfTentativa27.setBackground(Color.lightGray);
        }
        if (tfTentativa28.getText().equalsIgnoreCase(sDigito[2])){
            tfTentativa28.setBackground(Color.green);
        }else if (tfTentativa28.getText().equalsIgnoreCase(sDigito[0]) ||
                tfTentativa28.getText().equalsIgnoreCase(sDigito[1])||
                tfTentativa28.getText().equalsIgnoreCase(sDigito[3]) ||
                tfTentativa28.getText().equalsIgnoreCase(sDigito[4]) &&
                tfTentativa27.getBackground()!=Color.green){
            tfTentativa28.setBackground(Color.yellow);
        }else{
            tfTentativa28.setBackground(Color.lightGray);
        }
        if (tfTentativa29.getText().equalsIgnoreCase(sDigito[3])){
            tfTentativa29.setBackground(Color.green);
        }else if (tfTentativa29.getText().equalsIgnoreCase(sDigito[0]) ||
                tfTentativa29.getText().equalsIgnoreCase(sDigito[2])||
                tfTentativa29.getText().equalsIgnoreCase(sDigito[1]) ||
                tfTentativa29.getText().equalsIgnoreCase(sDigito[4])){
            tfTentativa29.setBackground(Color.yellow);
        }else{
            tfTentativa29.setBackground(Color.lightGray);
        }
        if (tfTentativa30.getText().equalsIgnoreCase(sDigito[4])){
            tfTentativa30.setBackground(Color.green);
        }else if (tfTentativa30.getText().equalsIgnoreCase(sDigito[0]) ||
                tfTentativa30.getText().equalsIgnoreCase(sDigito[2])||
                tfTentativa30.getText().equalsIgnoreCase(sDigito[1]) ||
                tfTentativa30.getText().equalsIgnoreCase(sDigito[3]) &&
                tfTentativa29.getBackground()!=Color.green){
            tfTentativa30.setBackground(Color.yellow);
        }else{
            tfTentativa30.setBackground(Color.lightGray);
        }
        iConta++;
        
    }
    public void Sortear (){
        iNumCerto= (int)(Math.random()*100000);
        sNum= String.valueOf(iNumCerto);
        sNum= sNum.replace(".", "");
        if (sNum.length()==4){
            sNum= "0"+sNum;
        }else if(sNum.length()==3){
            sNum= "00"+sNum;
        }else if(sNum.length()==2){
            sNum= "000"+sNum;
        }else if(sNum.length()==1){
            sNum= "0000"+sNum;
        }
        System.out.println(sNum);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lbTitulo = new javax.swing.JLabel();
        lbDescricao = new javax.swing.JLabel();
        pnTentativas = new javax.swing.JPanel();
        tfTentativa1 = new javax.swing.JTextField();
        tfTentativa2 = new javax.swing.JTextField();
        tfTentativa3 = new javax.swing.JTextField();
        tfTentativa4 = new javax.swing.JTextField();
        tfTentativa5 = new javax.swing.JTextField();
        tfTentativa6 = new javax.swing.JTextField();
        tfTentativa7 = new javax.swing.JTextField();
        tfTentativa8 = new javax.swing.JTextField();
        tfTentativa9 = new javax.swing.JTextField();
        tfTentativa10 = new javax.swing.JTextField();
        tfTentativa12 = new javax.swing.JTextField();
        tfTentativa13 = new javax.swing.JTextField();
        tfTentativa15 = new javax.swing.JTextField();
        tfTentativa11 = new javax.swing.JTextField();
        tfTentativa14 = new javax.swing.JTextField();
        tfTentativa18 = new javax.swing.JTextField();
        tfTentativa16 = new javax.swing.JTextField();
        tfTentativa20 = new javax.swing.JTextField();
        tfTentativa19 = new javax.swing.JTextField();
        tfTentativa17 = new javax.swing.JTextField();
        tfTentativa21 = new javax.swing.JTextField();
        tfTentativa24 = new javax.swing.JTextField();
        tfTentativa23 = new javax.swing.JTextField();
        tfTentativa22 = new javax.swing.JTextField();
        tfTentativa25 = new javax.swing.JTextField();
        tfTentativa28 = new javax.swing.JTextField();
        tfTentativa29 = new javax.swing.JTextField();
        tfTentativa27 = new javax.swing.JTextField();
        tfTentativa26 = new javax.swing.JTextField();
        tfTentativa30 = new javax.swing.JTextField();
        btnTestar = new javax.swing.JButton();
        btn0 = new javax.swing.JButton();
        btn1 = new javax.swing.JButton();
        btn2 = new javax.swing.JButton();
        btn3 = new javax.swing.JButton();
        btn4 = new javax.swing.JButton();
        btn5 = new javax.swing.JButton();
        btn6 = new javax.swing.JButton();
        btn7 = new javax.swing.JButton();
        btn8 = new javax.swing.JButton();
        btn9 = new javax.swing.JButton();
        btnApagar = new javax.swing.JButton();
        btnNovoJogo = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        lbPlacar = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        lbTitulo.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        lbTitulo.setForeground(new java.awt.Color(255, 0, 0));
        lbTitulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbTitulo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/somativa2/vermelho.png"))); // NOI18N
        lbTitulo.setText("ALGORÍTMO");
        lbTitulo.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);

        lbDescricao.setBackground(new java.awt.Color(255, 255, 204));
        lbDescricao.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbDescricao.setText("Ao começar uma nova partida, um numero aleatório de 5 digitos será sorteado... Sua função é tentar adivinhar esse número!");

        pnTentativas.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 255), 5));

        tfTentativa1.setEditable(false);
        tfTentativa1.setFont(new java.awt.Font("Tahoma", 1, 60)); // NOI18N
        tfTentativa1.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        tfTentativa2.setEditable(false);
        tfTentativa2.setFont(new java.awt.Font("Tahoma", 1, 60)); // NOI18N
        tfTentativa2.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        tfTentativa3.setEditable(false);
        tfTentativa3.setFont(new java.awt.Font("Tahoma", 1, 60)); // NOI18N
        tfTentativa3.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        tfTentativa4.setEditable(false);
        tfTentativa4.setFont(new java.awt.Font("Tahoma", 1, 60)); // NOI18N
        tfTentativa4.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        tfTentativa5.setEditable(false);
        tfTentativa5.setFont(new java.awt.Font("Tahoma", 1, 60)); // NOI18N
        tfTentativa5.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        tfTentativa6.setEditable(false);
        tfTentativa6.setFont(new java.awt.Font("Tahoma", 1, 60)); // NOI18N
        tfTentativa6.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        tfTentativa7.setEditable(false);
        tfTentativa7.setFont(new java.awt.Font("Tahoma", 1, 60)); // NOI18N
        tfTentativa7.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        tfTentativa8.setEditable(false);
        tfTentativa8.setFont(new java.awt.Font("Tahoma", 1, 60)); // NOI18N
        tfTentativa8.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        tfTentativa9.setEditable(false);
        tfTentativa9.setFont(new java.awt.Font("Tahoma", 1, 60)); // NOI18N
        tfTentativa9.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        tfTentativa10.setEditable(false);
        tfTentativa10.setFont(new java.awt.Font("Tahoma", 1, 60)); // NOI18N
        tfTentativa10.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        tfTentativa12.setEditable(false);
        tfTentativa12.setFont(new java.awt.Font("Tahoma", 1, 60)); // NOI18N
        tfTentativa12.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        tfTentativa12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfTentativa12ActionPerformed(evt);
            }
        });

        tfTentativa13.setEditable(false);
        tfTentativa13.setFont(new java.awt.Font("Tahoma", 1, 60)); // NOI18N
        tfTentativa13.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        tfTentativa15.setEditable(false);
        tfTentativa15.setFont(new java.awt.Font("Tahoma", 1, 60)); // NOI18N
        tfTentativa15.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        tfTentativa11.setEditable(false);
        tfTentativa11.setFont(new java.awt.Font("Tahoma", 1, 60)); // NOI18N
        tfTentativa11.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        tfTentativa14.setEditable(false);
        tfTentativa14.setFont(new java.awt.Font("Tahoma", 1, 60)); // NOI18N
        tfTentativa14.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        tfTentativa18.setEditable(false);
        tfTentativa18.setFont(new java.awt.Font("Tahoma", 1, 60)); // NOI18N
        tfTentativa18.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        tfTentativa16.setEditable(false);
        tfTentativa16.setFont(new java.awt.Font("Tahoma", 1, 60)); // NOI18N
        tfTentativa16.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        tfTentativa20.setEditable(false);
        tfTentativa20.setFont(new java.awt.Font("Tahoma", 1, 60)); // NOI18N
        tfTentativa20.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        tfTentativa19.setEditable(false);
        tfTentativa19.setFont(new java.awt.Font("Tahoma", 1, 60)); // NOI18N
        tfTentativa19.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        tfTentativa17.setEditable(false);
        tfTentativa17.setFont(new java.awt.Font("Tahoma", 1, 60)); // NOI18N
        tfTentativa17.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        tfTentativa21.setEditable(false);
        tfTentativa21.setFont(new java.awt.Font("Tahoma", 1, 60)); // NOI18N
        tfTentativa21.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        tfTentativa24.setEditable(false);
        tfTentativa24.setFont(new java.awt.Font("Tahoma", 1, 60)); // NOI18N
        tfTentativa24.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        tfTentativa23.setEditable(false);
        tfTentativa23.setFont(new java.awt.Font("Tahoma", 1, 60)); // NOI18N
        tfTentativa23.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        tfTentativa22.setEditable(false);
        tfTentativa22.setFont(new java.awt.Font("Tahoma", 1, 60)); // NOI18N
        tfTentativa22.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        tfTentativa25.setEditable(false);
        tfTentativa25.setFont(new java.awt.Font("Tahoma", 1, 60)); // NOI18N
        tfTentativa25.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        tfTentativa28.setEditable(false);
        tfTentativa28.setFont(new java.awt.Font("Tahoma", 1, 60)); // NOI18N
        tfTentativa28.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        tfTentativa29.setEditable(false);
        tfTentativa29.setFont(new java.awt.Font("Tahoma", 1, 60)); // NOI18N
        tfTentativa29.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        tfTentativa27.setEditable(false);
        tfTentativa27.setFont(new java.awt.Font("Tahoma", 1, 60)); // NOI18N
        tfTentativa27.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        tfTentativa26.setEditable(false);
        tfTentativa26.setFont(new java.awt.Font("Tahoma", 1, 60)); // NOI18N
        tfTentativa26.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        tfTentativa30.setEditable(false);
        tfTentativa30.setFont(new java.awt.Font("Tahoma", 1, 60)); // NOI18N
        tfTentativa30.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        javax.swing.GroupLayout pnTentativasLayout = new javax.swing.GroupLayout(pnTentativas);
        pnTentativas.setLayout(pnTentativasLayout);
        pnTentativasLayout.setHorizontalGroup(
            pnTentativasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnTentativasLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnTentativasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnTentativasLayout.createSequentialGroup()
                        .addComponent(tfTentativa1, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tfTentativa2, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tfTentativa3, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tfTentativa4, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tfTentativa5, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnTentativasLayout.createSequentialGroup()
                        .addComponent(tfTentativa6, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tfTentativa7, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tfTentativa8, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tfTentativa9, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tfTentativa10, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnTentativasLayout.createSequentialGroup()
                        .addComponent(tfTentativa11, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tfTentativa12, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tfTentativa13, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tfTentativa14, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tfTentativa15, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnTentativasLayout.createSequentialGroup()
                        .addComponent(tfTentativa16, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tfTentativa17, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tfTentativa18, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tfTentativa19, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tfTentativa20, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnTentativasLayout.createSequentialGroup()
                        .addComponent(tfTentativa21, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tfTentativa22, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tfTentativa23, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tfTentativa24, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tfTentativa25, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnTentativasLayout.createSequentialGroup()
                        .addComponent(tfTentativa26, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tfTentativa27, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tfTentativa28, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tfTentativa29, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tfTentativa30, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnTentativasLayout.setVerticalGroup(
            pnTentativasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnTentativasLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnTentativasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tfTentativa1, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfTentativa2, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfTentativa3, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfTentativa4, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfTentativa5, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnTentativasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tfTentativa6, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfTentativa7, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfTentativa8, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfTentativa9, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfTentativa10, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnTentativasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tfTentativa11, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfTentativa12, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfTentativa13, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfTentativa14, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfTentativa15, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnTentativasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tfTentativa16, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfTentativa17, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfTentativa18, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfTentativa19, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfTentativa20, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnTentativasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tfTentativa21, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfTentativa22, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfTentativa23, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfTentativa24, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfTentativa25, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnTentativasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tfTentativa26, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfTentativa27, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfTentativa28, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfTentativa29, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfTentativa30, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        btnTestar.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnTestar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/somativa2/icons8-play-dentro-de-um-círculo-30.png"))); // NOI18N
        btnTestar.setText("Testar");
        btnTestar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTestarActionPerformed(evt);
            }
        });

        btn0.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btn0.setText("0");
        btn0.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn0ActionPerformed(evt);
            }
        });

        btn1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btn1.setText("1");
        btn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn1ActionPerformed(evt);
            }
        });

        btn2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btn2.setText("2");
        btn2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn2ActionPerformed(evt);
            }
        });

        btn3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btn3.setText("3");
        btn3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn3ActionPerformed(evt);
            }
        });

        btn4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btn4.setText("4");
        btn4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn4ActionPerformed(evt);
            }
        });

        btn5.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btn5.setText("5");
        btn5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn5ActionPerformed(evt);
            }
        });

        btn6.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btn6.setText("6");
        btn6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn6ActionPerformed(evt);
            }
        });

        btn7.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btn7.setText("7");
        btn7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn7ActionPerformed(evt);
            }
        });

        btn8.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btn8.setText("8");
        btn8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn8ActionPerformed(evt);
            }
        });

        btn9.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btn9.setText("9");
        btn9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn9ActionPerformed(evt);
            }
        });

        btnApagar.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnApagar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/somativa2/icons8-pencil-eraser-24.png"))); // NOI18N
        btnApagar.setText("Apagar");
        btnApagar.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        btnApagar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnApagarActionPerformed(evt);
            }
        });

        btnNovoJogo.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnNovoJogo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/somativa2/icons8-ficheiro-binário-30.png"))); // NOI18N
        btnNovoJogo.setText("NOVO JOGO");
        btnNovoJogo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNovoJogoActionPerformed(evt);
            }
        });

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Caso o digito se torne amarelo, o mesmo se encontra no numero sorteado, porém em outra posição.");

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Caso o digito se torne verde, o mesmo se encontra no numero sorteado na mesma posição!!");

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("BOA SORTE!!");

        lbPlacar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/somativa2/icons8-resultados-do-teste-40.png"))); // NOI18N

        jLabel4.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        jLabel4.setText("PLACAR");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lbDescricao, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(lbTitulo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addComponent(btn0, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn1, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(48, 48, 48)
                        .addComponent(lbPlacar))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(59, 59, 59)
                        .addComponent(jLabel4)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(btn2, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btn3, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btn4, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(btnTestar, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btn5, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btn6, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btn7, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btn8, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btn9, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(btnApagar)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(107, 107, 107)
                        .addComponent(btnNovoJogo)))
                .addContainerGap(44, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(pnTentativas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(78, 78, 78))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbTitulo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbDescricao, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(2, 2, 2)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel3)
                .addGap(5, 5, 5)
                .addComponent(pnTentativas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn0, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn4, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn5, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn6, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn7, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn8, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn9, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnTestar, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnApagar, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnNovoJogo, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lbPlacar)))
                .addContainerGap(25, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnNovoJogoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNovoJogoActionPerformed
        limparTudo();
        tfTentativa1.requestFocus();
        Sortear();
        iConta=0;
    }//GEN-LAST:event_btnNovoJogoActionPerformed

    private void btn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn1ActionPerformed
        tf[iConta].setText("1");
        if (iConta==4 || iConta==9 || iConta==14 || iConta==19 || iConta==24 || iConta==29){
            requestFocus(false);
        }else{
        iConta++;
        tf[iConta].requestFocus();
        }
    }//GEN-LAST:event_btn1ActionPerformed

    private void btn0ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn0ActionPerformed
        tf[iConta].setText("0");
        if (iConta==4 || iConta==9 || iConta==14 || iConta==19 || iConta==24 || iConta==29){
            requestFocus(false);
        }else{
            iConta++;
            tf[iConta].requestFocus();
        }
    }//GEN-LAST:event_btn0ActionPerformed

    private void btn2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn2ActionPerformed
        tf[iConta].setText("2");
        if (iConta==4 || iConta==9 || iConta==14 || iConta==19 || iConta==24 || iConta==29){
            requestFocus(false);
        }else{
            iConta++;
            tf[iConta].requestFocus();
        }
    }//GEN-LAST:event_btn2ActionPerformed

    private void btn3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn3ActionPerformed
        tf[iConta].setText("3");
        if (iConta==4 || iConta==9 || iConta==14 || iConta==19 || iConta==24 || iConta==29){
            requestFocus(false);
        }else{
            iConta++;
            tf[iConta].requestFocus();
        }
    }//GEN-LAST:event_btn3ActionPerformed

    private void btn4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn4ActionPerformed
        tf[iConta].setText("4");
        if (iConta==4 || iConta==9 || iConta==14 || iConta==19 || iConta==24 || iConta==29){
            requestFocus(false);
        }else{
            iConta++;
            tf[iConta].requestFocus();
        }
    }//GEN-LAST:event_btn4ActionPerformed

    private void btn5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn5ActionPerformed
        tf[iConta].setText("5");
        if (iConta==4 || iConta==9 || iConta==14 || iConta==19 || iConta==24 || iConta==29){
            requestFocus(false);
        }else{
            iConta++;
            tf[iConta].requestFocus();
        }
    }//GEN-LAST:event_btn5ActionPerformed

    private void btn6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn6ActionPerformed
        tf[iConta].setText("6");
        if (iConta==4 || iConta==9 || iConta==14 || iConta==19 || iConta==24 || iConta==29){
            requestFocus(false);
        }else{
            iConta++;
            tf[iConta].requestFocus();
        }
    }//GEN-LAST:event_btn6ActionPerformed

    private void btn7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn7ActionPerformed
        tf[iConta].setText("7");
        if (iConta==4 || iConta==9 || iConta==14 || iConta==19 || iConta==24 || iConta==29){
            requestFocus(false);
        }else{
            iConta++;
            tf[iConta].requestFocus();
        }
    }//GEN-LAST:event_btn7ActionPerformed

    private void btn8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn8ActionPerformed
        tf[iConta].setText("8");
        if (iConta==4 || iConta==9 || iConta==14 || iConta==19 || iConta==24 || iConta==29){
            requestFocus(false);
        }else{
            iConta++;
            tf[iConta].requestFocus();
        }
    }//GEN-LAST:event_btn8ActionPerformed

    private void btn9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn9ActionPerformed
        tf[iConta].setText("9");
        if (iConta==4 || iConta==9 || iConta==14 || iConta==19 || iConta==24 || iConta==29){
            requestFocus(false);
        }else{
            iConta++;
            tf[iConta].requestFocus();
        }
    }//GEN-LAST:event_btn9ActionPerformed

    private void btnApagarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnApagarActionPerformed
        tf[iConta].setText("");
        if(iConta!=0  && iConta!=5 && iConta!=10 && iConta!=15 &&  iConta!=20 && iConta!=25 ){
            iConta--;
             tf[iConta].requestFocus();  
        }else{
            tf[iConta].requestFocus();
        }
        
    }//GEN-LAST:event_btnApagarActionPerformed

    private void tfTentativa12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfTentativa12ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfTentativa12ActionPerformed

    private void btnTestarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTestarActionPerformed
        if(iConta==4 && !tfTentativa5.getText().equals("")){
            TestarLinha1();
            if(tfTentativa1.getBackground()==Color.GREEN &&
            tfTentativa2.getBackground()==Color.GREEN &&
            tfTentativa3.getBackground()==Color.GREEN &&
            tfTentativa4.getBackground()==Color.GREEN &&
            tfTentativa5.getBackground()==Color.GREEN){
                JOptionPane.showMessageDialog(null, "PARABÉNS, VOCÊ ACERTOU!!");
                requestFocus(false);
                iPlacar++;
                lbPlacar.setText(String.valueOf(iPlacar));
           }
        }else if (iConta==9 && !tfTentativa10.getText().equals("")){
            TestarLinha2();
            if(tfTentativa6.getBackground()==Color.GREEN &&
            tfTentativa7.getBackground()==Color.GREEN &&
            tfTentativa8.getBackground()==Color.GREEN &&
            tfTentativa9.getBackground()==Color.GREEN &&
            tfTentativa10.getBackground()==Color.GREEN){
                JOptionPane.showMessageDialog(null, "PARABÉNS, VOCÊ ACERTOU!!");
                requestFocus(false);
                iPlacar++;
                lbPlacar.setText(String.valueOf(iPlacar));
            }
        }else if (iConta==14 && !tfTentativa15.getText().equals("")){
            TestarLinha3();
            if(tfTentativa11.getBackground()==Color.GREEN &&
            tfTentativa12.getBackground()==Color.GREEN &&
            tfTentativa13.getBackground()==Color.GREEN &&
            tfTentativa14.getBackground()==Color.GREEN &&
            tfTentativa15.getBackground()==Color.GREEN){
                JOptionPane.showMessageDialog(null, "PARABÉNS, VOCÊ ACERTOU!!");
                requestFocus(false);
                iPlacar++;
                lbPlacar.setText(String.valueOf(iPlacar));
            }
        }else if (iConta==19 && !tfTentativa20.getText().equals("")){
            TestarLinha4();
            if(tfTentativa16.getBackground()==Color.GREEN &&
            tfTentativa17.getBackground()==Color.GREEN &&
            tfTentativa18.getBackground()==Color.GREEN &&
            tfTentativa19.getBackground()==Color.GREEN &&
            tfTentativa20.getBackground()==Color.GREEN){
                JOptionPane.showMessageDialog(null, "PARABÉNS, VOCÊ ACERTOU!!");
                requestFocus(false);
                iPlacar++;
                lbPlacar.setText(String.valueOf(iPlacar));
            }
        }else if (iConta==24 && !tfTentativa25.getText().equals("")){
            TestarLinha5();
            if(tfTentativa21.getBackground()==Color.GREEN &&
            tfTentativa22.getBackground()==Color.GREEN &&
            tfTentativa23.getBackground()==Color.GREEN &&
            tfTentativa24.getBackground()==Color.GREEN &&
            tfTentativa25.getBackground()==Color.GREEN){
                JOptionPane.showMessageDialog(null, "PARABÉNS, VOCÊ ACERTOU!!");
                requestFocus(false);
                iPlacar++;
                lbPlacar.setText(String.valueOf(iPlacar));
            }
        }else if (iConta==29 && !tfTentativa30.getText().equals("")){
            TestarLinha6();
            if(tfTentativa26.getBackground()==Color.GREEN &&
            tfTentativa27.getBackground()==Color.GREEN &&
            tfTentativa28.getBackground()==Color.GREEN &&
            tfTentativa29.getBackground()==Color.GREEN &&
            tfTentativa30.getBackground()==Color.GREEN){
                JOptionPane.showMessageDialog(null, "PARABÉNS, VOCÊ ACERTOU!!");
                requestFocus(false);
                iPlacar++;
                lbPlacar.setText(String.valueOf(iPlacar));
            }
        }else if (iConta==29 && tfTentativa26.getBackground()!=Color.GREEN ||
            tfTentativa27.getBackground()!=Color.GREEN ||
            tfTentativa28.getBackground()!=Color.GREEN ||
            tfTentativa29.getBackground()!=Color.GREEN ||
            tfTentativa30.getBackground()!=Color.GREEN){
                JOptionPane.showMessageDialog(null, "VOCÊ PERDEU, CASO QUEIRA CONTINUAR, COMECE UM NOVO JOGO:("); 
        }else{
            JOptionPane.showMessageDialog(null, "POR FAVOR DIGITE UM NÚMERO COM 5 DIGITOS");
            tf[iConta].requestFocus();
        }
        
    }//GEN-LAST:event_btnTestarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Judith.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Judith.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Judith.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Judith.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Judith().setVisible(true);
            }
        });
    }
    public void limparTudo(){
        for (int i = 0; i < tf.length; i++) {
            tf[i].setBackground(Color.white);
            tf[i].setText(null);
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn0;
    private javax.swing.JButton btn1;
    private javax.swing.JButton btn2;
    private javax.swing.JButton btn3;
    private javax.swing.JButton btn4;
    private javax.swing.JButton btn5;
    private javax.swing.JButton btn6;
    private javax.swing.JButton btn7;
    private javax.swing.JButton btn8;
    private javax.swing.JButton btn9;
    private javax.swing.JButton btnApagar;
    private javax.swing.JButton btnNovoJogo;
    private javax.swing.JButton btnTestar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel lbDescricao;
    private javax.swing.JLabel lbPlacar;
    private javax.swing.JLabel lbTitulo;
    private javax.swing.JPanel pnTentativas;
    private javax.swing.JTextField tfTentativa1;
    private javax.swing.JTextField tfTentativa10;
    private javax.swing.JTextField tfTentativa11;
    private javax.swing.JTextField tfTentativa12;
    private javax.swing.JTextField tfTentativa13;
    private javax.swing.JTextField tfTentativa14;
    private javax.swing.JTextField tfTentativa15;
    private javax.swing.JTextField tfTentativa16;
    private javax.swing.JTextField tfTentativa17;
    private javax.swing.JTextField tfTentativa18;
    private javax.swing.JTextField tfTentativa19;
    private javax.swing.JTextField tfTentativa2;
    private javax.swing.JTextField tfTentativa20;
    private javax.swing.JTextField tfTentativa21;
    private javax.swing.JTextField tfTentativa22;
    private javax.swing.JTextField tfTentativa23;
    private javax.swing.JTextField tfTentativa24;
    private javax.swing.JTextField tfTentativa25;
    private javax.swing.JTextField tfTentativa26;
    private javax.swing.JTextField tfTentativa27;
    private javax.swing.JTextField tfTentativa28;
    private javax.swing.JTextField tfTentativa29;
    private javax.swing.JTextField tfTentativa3;
    private javax.swing.JTextField tfTentativa30;
    private javax.swing.JTextField tfTentativa4;
    private javax.swing.JTextField tfTentativa5;
    private javax.swing.JTextField tfTentativa6;
    private javax.swing.JTextField tfTentativa7;
    private javax.swing.JTextField tfTentativa8;
    private javax.swing.JTextField tfTentativa9;
    // End of variables declaration//GEN-END:variables
    int iConta=0;
    int iNumCerto;
    String sNum;  
    int iPlacar=0;
}
